create view employee_view(name, last_name, count, max, avg, row_number, rank, dense_rank, lag) as
SELECT c.name,
       e.last_name,
       count(e.id) OVER ()                    AS count,
       max(e.salary) OVER ()                  AS max,
       avg(e.salary) OVER ()                  AS avg,
       row_number() OVER ()                   AS row_number,
       rank() OVER (ORDER BY e.salary)        AS rank,
       dense_rank() OVER (ORDER BY e.salary)  AS dense_rank,
       lag(e.salary) OVER (ORDER BY e.salary) AS lag
FROM company_storage.company c
         LEFT JOIN company_storage.employee e ON c.id = e.company_id;

alter table employee_view
    owner to postgres;

